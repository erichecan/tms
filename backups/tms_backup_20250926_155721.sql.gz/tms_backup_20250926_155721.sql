--
-- PostgreSQL database dump
--

\restrict chN1mi9xRbH39dROmcmtlAds7BnffDU9IoETSJWOzRiQSiB9TWXI3hXdYthHbiq

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assignments; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.assignments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    shipment_id uuid,
    driver_id uuid,
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.assignments OWNER TO tms_user;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.customers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    name character varying(255) NOT NULL,
    level character varying(50) DEFAULT 'standard'::character varying,
    contact_info jsonb DEFAULT '{}'::jsonb,
    billing_info jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customers OWNER TO tms_user;

--
-- Name: drivers; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.drivers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    name character varying(255) NOT NULL,
    phone character varying(20),
    license_number character varying(50),
    vehicle_info jsonb DEFAULT '{}'::jsonb,
    status character varying(20) DEFAULT 'available'::character varying,
    performance jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    vehicle_id uuid
);


ALTER TABLE public.drivers OWNER TO tms_user;

--
-- Name: financial_records; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.financial_records (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    type character varying(50) NOT NULL,
    reference_id uuid NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'CNY'::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    due_date date,
    paid_at timestamp without time zone,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.financial_records OWNER TO tms_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.notifications (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    type character varying(50) NOT NULL,
    target_role character varying(50) NOT NULL,
    shipment_id uuid,
    driver_id uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    payload jsonb DEFAULT '{}'::jsonb,
    delivered boolean DEFAULT false
);


ALTER TABLE public.notifications OWNER TO tms_user;

--
-- Name: proof_of_delivery; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.proof_of_delivery (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    shipment_id uuid,
    file_path text NOT NULL,
    uploaded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    uploaded_by character varying(20) NOT NULL,
    note text
);


ALTER TABLE public.proof_of_delivery OWNER TO tms_user;

--
-- Name: rule_executions; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.rule_executions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    rule_id uuid,
    context jsonb NOT NULL,
    result jsonb NOT NULL,
    execution_time integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.rule_executions OWNER TO tms_user;

--
-- Name: rules; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    name character varying(255) NOT NULL,
    description text,
    type character varying(50) NOT NULL,
    priority integer NOT NULL,
    conditions jsonb NOT NULL,
    actions jsonb NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.rules OWNER TO tms_user;

--
-- Name: shipments; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.shipments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    shipment_number character varying(50) NOT NULL,
    customer_id uuid,
    driver_id uuid,
    pickup_address jsonb NOT NULL,
    delivery_address jsonb NOT NULL,
    cargo_info jsonb NOT NULL,
    estimated_cost numeric(10,2),
    actual_cost numeric(10,2),
    additional_fees jsonb DEFAULT '[]'::jsonb,
    applied_rules jsonb DEFAULT '[]'::jsonb,
    status character varying(50) DEFAULT 'created'::character varying,
    timeline jsonb DEFAULT '{}'::jsonb,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    shipper_name character varying(255),
    shipper_phone character varying(50),
    shipper_addr_line1 character varying(255),
    shipper_city character varying(100),
    shipper_province character varying(100),
    shipper_postal_code character varying(20),
    shipper_country character varying(100),
    receiver_name character varying(255),
    receiver_phone character varying(50),
    receiver_addr_line1 character varying(255),
    receiver_city character varying(100),
    receiver_province character varying(100),
    receiver_postal_code character varying(20),
    receiver_country character varying(100),
    weight_kg numeric(10,2),
    dimensions jsonb,
    final_cost numeric(10,2)
);


ALTER TABLE public.shipments OWNER TO tms_user;

--
-- Name: statements; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.statements (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    type character varying(50) NOT NULL,
    reference_id uuid NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    items jsonb NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    status character varying(20) DEFAULT 'draft'::character varying,
    generated_at timestamp without time zone NOT NULL,
    generated_by character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.statements OWNER TO tms_user;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.tenants (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    domain character varying(255) NOT NULL,
    schema_name character varying(63) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    settings jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tenants OWNER TO tms_user;

--
-- Name: timeline_events; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.timeline_events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    shipment_id uuid,
    event_type character varying(50) NOT NULL,
    from_status character varying(50),
    to_status character varying(50),
    actor_type character varying(20) NOT NULL,
    actor_id uuid,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    extra jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.timeline_events OWNER TO tms_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(50) NOT NULL,
    profile jsonb DEFAULT '{}'::jsonb,
    status character varying(20) DEFAULT 'active'::character varying,
    last_login_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO tms_user;

--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.vehicles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    plate_number character varying(50) NOT NULL,
    type character varying(50) NOT NULL,
    capacity_kg numeric(10,2),
    status character varying(20) DEFAULT 'available'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.vehicles OWNER TO tms_user;

--
-- Data for Name: assignments; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.assignments (id, shipment_id, driver_id, assigned_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.customers (id, tenant_id, name, level, contact_info, billing_info, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	示例客户公司	vip	{"email": "customer@example.com", "phone": "13800138000", "address": {"city": "北京", "state": "北京", "street": "示例街道123号", "country": "中国", "postalCode": "100000"}, "contactPerson": "张经理"}	{"taxId": "91110000000000000X", "companyName": "示例客户公司", "paymentTerms": "月结30天", "billingAddress": {"city": "北京", "state": "北京", "street": "示例街道123号", "country": "中国", "postalCode": "100000"}}	2025-09-23 22:53:26.17861	2025-09-23 22:53:26.17861
a349d7d9-2d7e-4410-9586-88dc1aa5fd4f	00000000-0000-0000-0000-000000000001	wenbin	standard	{"email": "eric@qq.com", "phone": "14372999568", "address": {"city": "Default City", "state": "Default State", "street": "Default Street", "country": "Default Country", "postalCode": "000000"}}	\N	2025-09-26 19:54:59.798966	2025-09-26 19:54:59.798966
\.


--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.drivers (id, tenant_id, name, phone, license_number, vehicle_info, status, performance, created_at, updated_at, vehicle_id) FROM stdin;
00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	李司机	13900139000	A123456789	{"type": "truck", "capacity": 10000, "features": ["尾板", "GPS"], "dimensions": {"width": 2.5, "height": 2.8, "length": 6}, "licensePlate": "京A12345"}	active	{"rating": 4.8, "onTimeRate": 0.95, "totalDeliveries": 150, "customerSatisfaction": 0.92}	2025-09-23 22:53:26.179294	2025-09-23 22:53:26.179294	\N
\.


--
-- Data for Name: financial_records; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.financial_records (id, tenant_id, type, reference_id, amount, currency, status, due_date, paid_at, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.notifications (id, type, target_role, shipment_id, driver_id, created_at, payload, delivered) FROM stdin;
\.


--
-- Data for Name: proof_of_delivery; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.proof_of_delivery (id, shipment_id, file_path, uploaded_at, uploaded_by, note) FROM stdin;
\.


--
-- Data for Name: rule_executions; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.rule_executions (id, tenant_id, rule_id, context, result, execution_time, created_at) FROM stdin;
\.


--
-- Data for Name: rules; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.rules (id, tenant_id, name, description, type, priority, conditions, actions, status, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	VIP客户长途折扣	VIP客户运输距离超过500公里时享受15%折扣	pricing	100	[{"fact": "customerLevel", "value": "vip", "operator": "equal"}, {"fact": "transportDistance", "value": 500, "operator": "greaterThan"}]	[{"type": "applyDiscount", "params": {"percentage": 15}}]	active	2025-09-23 22:53:26.179936	2025-09-23 22:53:26.179936
00000000-0000-0000-0000-000000000002	00000000-0000-0000-0000-000000000001	司机基础提成	所有司机基础提成30%	payroll	300	[{"fact": "driverId", "value": "", "operator": "isNotEmpty"}]	[{"type": "setDriverCommission", "params": {"percentage": 30}}]	active	2025-09-23 22:53:26.180562	2025-09-23 22:53:26.180562
\.


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.shipments (id, tenant_id, shipment_number, customer_id, driver_id, pickup_address, delivery_address, cargo_info, estimated_cost, actual_cost, additional_fees, applied_rules, status, timeline, notes, created_at, updated_at, shipper_name, shipper_phone, shipper_addr_line1, shipper_city, shipper_province, shipper_postal_code, shipper_country, receiver_name, receiver_phone, receiver_addr_line1, receiver_city, receiver_province, receiver_postal_code, receiver_country, weight_kg, dimensions, final_cost) FROM stdin;
a41ab2c5-334d-4ce4-8386-4e5ff0ba86f3	00000000-0000-0000-0000-000000000001	SH20250923185841981	\N	\N	{"city": "北京", "name": "张三", "phone": "13800138000", "country": "中国", "province": "北京", "postalCode": "", "addressLine1": "北京市朝阳区测试街道123号"}	{"city": "上海", "name": "李四", "phone": "13900139000", "country": "中国", "province": "上海", "postalCode": "", "addressLine1": "上海市浦东新区测试路456号"}	{"items": [], "weightKg": 5.5}	\N	\N	[]	[]	created	{"created": "2025-09-23T22:58:41.981Z"}	\N	2025-09-23 22:58:42.007242	2025-09-23 22:58:42.007242	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3db3c1a2-d131-46b8-ba54-4ac94f32d7a6	00000000-0000-0000-0000-000000000001	TMS202509260001	a349d7d9-2d7e-4410-9586-88dc1aa5fd4f	\N	{"city": "Markham", "state": "Ontario", "street": "1399 Kennedy", "country": "CA", "postalCode": "L3r 5w7"}	{"city": "Markham", "state": "Ontario", "street": "8345 Kennedy", "country": "CA", "postalCode": "l6w 7r7"}	{"value": 0, "volume": 1000, "weight": 10, "hazardous": false, "dimensions": {"width": 10, "height": 10, "length": 10}, "description": "", "specialRequirements": []}	115.00	\N	[]	[]	pending	{"created": "2025-09-26T19:54:59.818Z"}	\N	2025-09-26 19:54:59.818454	2025-09-26 19:54:59.818454	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: statements; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.statements (id, tenant_id, type, reference_id, period_start, period_end, items, total_amount, status, generated_at, generated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.tenants (id, name, domain, schema_name, status, settings, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	TMS Demo Company	demo.tms-platform.com	tenant_demo	active	{}	2025-09-23 22:53:26.107312	2025-09-23 22:53:26.107312
\.


--
-- Data for Name: timeline_events; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.timeline_events (id, shipment_id, event_type, from_status, to_status, actor_type, actor_id, "timestamp", extra) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.users (id, tenant_id, email, password_hash, role, profile, status, last_login_at, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	admin@demo.tms-platform.com	$2a$10$GplA4J5iV/b/9gA.Ie3m.OqISjLdC0caN203n4i/TEc2T5.ZDCz/6	admin	{}	active	\N	2025-09-23 22:53:26.108022	2025-09-23 22:53:26.108022
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.vehicles (id, plate_number, type, capacity_kg, status, created_at, updated_at) FROM stdin;
\.


--
-- Name: assignments assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: drivers drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pkey PRIMARY KEY (id);


--
-- Name: financial_records financial_records_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.financial_records
    ADD CONSTRAINT financial_records_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: proof_of_delivery proof_of_delivery_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.proof_of_delivery
    ADD CONSTRAINT proof_of_delivery_pkey PRIMARY KEY (id);


--
-- Name: rule_executions rule_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.rule_executions
    ADD CONSTRAINT rule_executions_pkey PRIMARY KEY (id);


--
-- Name: rules rules_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.rules
    ADD CONSTRAINT rules_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_shipment_number_key; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_shipment_number_key UNIQUE (shipment_number);


--
-- Name: statements statements_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.statements
    ADD CONSTRAINT statements_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_domain_key; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_domain_key UNIQUE (domain);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_schema_name_key; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_schema_name_key UNIQUE (schema_name);


--
-- Name: timeline_events timeline_events_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.timeline_events
    ADD CONSTRAINT timeline_events_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_tenant_id_email_key; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_email_key UNIQUE (tenant_id, email);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_plate_number_key; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_plate_number_key UNIQUE (plate_number);


--
-- Name: idx_assignments_driver_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_assignments_driver_id ON public.assignments USING btree (driver_id);


--
-- Name: idx_assignments_shipment_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_assignments_shipment_id ON public.assignments USING btree (shipment_id);


--
-- Name: idx_customers_level; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_customers_level ON public.customers USING btree (level);


--
-- Name: idx_customers_tenant_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_customers_tenant_id ON public.customers USING btree (tenant_id);


--
-- Name: idx_drivers_status; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_drivers_status ON public.drivers USING btree (status);


--
-- Name: idx_drivers_tenant_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_drivers_tenant_id ON public.drivers USING btree (tenant_id);


--
-- Name: idx_drivers_vehicle_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_drivers_vehicle_id ON public.drivers USING btree (vehicle_id);


--
-- Name: idx_financial_records_reference_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_financial_records_reference_id ON public.financial_records USING btree (reference_id);


--
-- Name: idx_financial_records_status; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_financial_records_status ON public.financial_records USING btree (status);


--
-- Name: idx_financial_records_tenant_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_financial_records_tenant_id ON public.financial_records USING btree (tenant_id);


--
-- Name: idx_financial_records_type; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_financial_records_type ON public.financial_records USING btree (type);


--
-- Name: idx_notifications_shipment_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_notifications_shipment_id ON public.notifications USING btree (shipment_id);


--
-- Name: idx_notifications_type; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_notifications_type ON public.notifications USING btree (type);


--
-- Name: idx_pod_shipment_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_pod_shipment_id ON public.proof_of_delivery USING btree (shipment_id);


--
-- Name: idx_rule_executions_rule_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_rule_executions_rule_id ON public.rule_executions USING btree (rule_id);


--
-- Name: idx_rule_executions_tenant_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_rule_executions_tenant_id ON public.rule_executions USING btree (tenant_id);


--
-- Name: idx_rules_priority; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_rules_priority ON public.rules USING btree (priority);


--
-- Name: idx_rules_status; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_rules_status ON public.rules USING btree (status);


--
-- Name: idx_rules_tenant_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_rules_tenant_id ON public.rules USING btree (tenant_id);


--
-- Name: idx_rules_type; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_rules_type ON public.rules USING btree (type);


--
-- Name: idx_shipments_customer_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_shipments_customer_id ON public.shipments USING btree (customer_id);


--
-- Name: idx_shipments_driver_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_shipments_driver_id ON public.shipments USING btree (driver_id);


--
-- Name: idx_shipments_shipment_number; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_shipments_shipment_number ON public.shipments USING btree (shipment_number);


--
-- Name: idx_shipments_status; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_shipments_status ON public.shipments USING btree (status);


--
-- Name: idx_shipments_tenant_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_shipments_tenant_id ON public.shipments USING btree (tenant_id);


--
-- Name: idx_statements_reference_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_statements_reference_id ON public.statements USING btree (reference_id);


--
-- Name: idx_statements_status; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_statements_status ON public.statements USING btree (status);


--
-- Name: idx_statements_tenant_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_statements_tenant_id ON public.statements USING btree (tenant_id);


--
-- Name: idx_statements_type; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_statements_type ON public.statements USING btree (type);


--
-- Name: idx_tenants_domain; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_tenants_domain ON public.tenants USING btree (domain);


--
-- Name: idx_tenants_schema_name; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_tenants_schema_name ON public.tenants USING btree (schema_name);


--
-- Name: idx_timeline_events_event_type; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_timeline_events_event_type ON public.timeline_events USING btree (event_type);


--
-- Name: idx_timeline_events_shipment_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_timeline_events_shipment_id ON public.timeline_events USING btree (shipment_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_tenant_id; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_users_tenant_id ON public.users USING btree (tenant_id);


--
-- Name: assignments assignments_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE SET NULL;


--
-- Name: assignments assignments_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.shipments(id) ON DELETE CASCADE;


--
-- Name: customers customers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: drivers drivers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: drivers drivers_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: financial_records financial_records_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.financial_records
    ADD CONSTRAINT financial_records_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id);


--
-- Name: notifications notifications_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.shipments(id) ON DELETE CASCADE;


--
-- Name: proof_of_delivery proof_of_delivery_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.proof_of_delivery
    ADD CONSTRAINT proof_of_delivery_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.shipments(id) ON DELETE CASCADE;


--
-- Name: rule_executions rule_executions_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.rule_executions
    ADD CONSTRAINT rule_executions_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.rules(id);


--
-- Name: rule_executions rule_executions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.rule_executions
    ADD CONSTRAINT rule_executions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: rules rules_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.rules
    ADD CONSTRAINT rules_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: shipments shipments_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: shipments shipments_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id);


--
-- Name: shipments shipments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: statements statements_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.statements
    ADD CONSTRAINT statements_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: timeline_events timeline_events_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.timeline_events
    ADD CONSTRAINT timeline_events_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.shipments(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict chN1mi9xRbH39dROmcmtlAds7BnffDU9IoETSJWOzRiQSiB9TWXI3hXdYthHbiq

